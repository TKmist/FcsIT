# <h1 align="center">FcsIT</h1>

<p align="center">A simple and easy-to-use tool for correlating and fitting the fluorescence correlation spectroscopy (FCS) data.</p>

<h1></h1>

<p align="center">
  <a href="https://TKmist.github.io/FcsIT/">
    <img src="https://img.shields.io/badge/manual-online-darkgreen" />
  </a>
  <img src="https://img.shields.io/badge/Python-3.11%20%7C%203.12-3776AB?logo=python&logoColor=white" />
  <img src="https://img.shields.io/badge/platform-Windows%20%7C%20Linux-lightgrey" />
  <img src="https://img.shields.io/badge/version-V2.0.2-green" />
  
</p>
<p align="center">
  
  <a href="https://www.gnu.org/licenses/gpl-3.0">
    <img src="https://img.shields.io/badge/license-GPLv3-blue.svg" />
  </a>
  <a href="https://github.com/TKmist/FcsIT/releases/latest">
    <img src="https://img.shields.io/github/v/release/TKmist/FcsIT?label=download&sort=date&cacheSeconds=300" />
  </a>
  <a href="https://doi.org/10.5281/zenodo.19351493"><img src="https://zenodo.org/badge/DOI/10.5281/zenodo.19351493.svg" alt="DOI"/></a>
</p>

<p align="center">
  <a href="#information">Information</a> •
  <a href="#installation">Installation</a> •
  <a href="#release-notes">Release notes</a> •
  <a href="#license">License</a>
</p>
<h1></h1>

## Information
FcsIT is a tool designed for analysing fluorescence correlation spectroscopy data in a platform-independent manner. It features an intuitive, easy-to-navigate interface powered by [Dear PyGui](https://github.com/hoffstadt/DearPyGui). 
It provides:    
- Reading the TTTR data,    
- TCSPC-based filtering,    
- Correlation of the TTTR data,    
- Bootstrap standard errors of mean correlation curves, using the ordinary non-parametric bootstrap for `L=1` and the circular-block bootstrap for `L>1`,
- Empirical cross-lag covariance stored in new `.corr` files and used for post-hoc sandwich uncertainties of fitted parameters when sufficiently supported,
- Selectable `average` and `first` multi-tau compression for Time-binned correlation,
- Nine predefined mathematical models for fitting FCS data,    
- A local TCP/JSON interface for reproducible scripted workflows,
- Flexibility and user-friendly tools for adding user-defined models.


The software was developed and tested on PTU files created with the PicoHarp 300 TTTR system (PicoQuant, Germany). Further development to include other file formats is possible depending on the data availability. If you think this program might be useful for your studies but your files are not yet supported, feel free to contact the [author](mailto:tkalwarczyk@ichf.edu.pl).

## Installation
On Linux machines, it is highly recommended to install Python 3.11 or 3.12. The Windows installation files are distributed together with the Python Embedded Distribution for Windows. Follow the steps below to install the software.    
1. Go to the release folder. Choose your OS version (Windows or Linux), download the proper *FcsIT_(version)_(OS)* file and extract it to the desired location.

2. Go to the extracted directory and run the installation script:

    1. On Linux in a terminal, run the bash script by typing:
   
       ./install.sh
       
    2. On Windows, double-click the _install_win.bat_ executable script.
  
Make sure you are not using a VPN, as it may block the installation of PIP in the Python embedded distribution. 
  
The installation script will download all required packages, create the run_FcsIT script or run_FcsIT.bat (on Windows), and create the shortcuts. 

## Release notes

#### V2.0.2
 - Added explicit bootstrap block-length and segment-count controls to PTU/PT3 and Time-binned correlation, including valid-range enforcement. `L=1` selects the ordinary non-parametric bootstrap; `L>1` selects circular-block resampling of consecutive segments.
 - Added `average`/`first` multi-tau compression selection, bin-aware minimum-lag validation, and data-driven lag-grid limits for Time-binned correlation.
 - Separated PTU display binning from correlation settings and improved large-trace display, memory-error recovery, action-state restoration, and duplicate-run prevention.
 - Added persistent `runtime_log.txt` diagnostics for Python exceptions and fatal errors.
 - Fixed fitting with missing, zero, or non-finite errors, fitted-range and residual handling, brightness restoration, stored-result synchronisation, and aggregate brightness, reduced-chi-square, and p-value statistics.
 - Updated terminology from chunks to segments and documented the V2.0.2 bootstrap block-length, multi-tau compression, data-driven lag, and TCP/JSON controls.
 - Extended TCP/JSON parameter control and state reporting for bootstrap block length and Time-binned multi-tau compression; long-running commands wait for completion without a response timeout.

#### V2.0.1
 - Fixed the **Calculate filter** button callback and ensured that TCSPC filtering is executed when enabled.
 - Fixed PIE detection and the default fluorescence-lifetime gating range for channel 1, and ensured that photons outside the selected gate are excluded.
 - Added automatic Jupyter Book documentation building and installation during application installation and updates on Linux and Windows.

#### V2.0.0
 - Improved update algorithm.
 - Added PTU and PT3 input through `phconvert`.
 - Added lag-covariance estimation to the circular-block bootstrap and removed the non-circular `M / (M - L + 1)` variance multiplier.
 - Added post-hoc sandwich parameter errors for new covariance-aware `.corr` files; legacy and ASCII files retain diagonal LM errors.
 - Added automatic `.dat` and `.corr` export to the Time-binned correlation module.
 - Added local TCP/JSON and `fcsit_call` interfaces for scripted analysis.
 - Added a consent-based dependency migration for existing installations that need `phconvert`; fitting and time-binned analysis remain available if installation is postponed.
 - Improved handling of unequal chunks, missing long-lag values, and covariance stability.
 - Added platform-safe parallel Time-binned correlation for Linux and Windows.
 - Extended theme, settings, result-export, and update-status handling.

#### v1.0.6
 - Now reads and correlates data acquired in the T2 mode. The TCSPC filtering option is disabled for that data.
#### v1.0.5
 - Python embedded folder fixed.
#### v1.0.4
 - Optimalisation of operations on chunks,
#### v1.0.3

 - Optional _light_ theme added,
 - Settings window moved to the new class in the INIT.py file.

#### v1.0.0
This is an initial release of the FcsIT software
## License

This project is licensed under the GNU General Public License v3.0 or later.
See the [LICENSE](LICENSE) file for the full license text.

This program is distributed WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

### Third-party components

This software incorporates a modified version of the `correlation_methods.py`
file [originally developed by Dominic Waithe](https://github.com/dwaithe/FCS_point_correlator/blob/master/focuspoint/correlation_methods/correlation_methods.py).

The original work is licensed under the GNU General Public License v2 or later.

Modifications were made for integration and customisation for this project.
Details of modifications are provided in the [modified file](src/Methods/PTU_Corr/include/correlation_methods.py).

---

PicoQuant PTU and PT3 files are read with the open-source `phconvert`
dependency, which is installed automatically by `pip` from `setup.py` and is
distributed under the MIT License.

---

This software includes the Python Embedded Distribution for Windows,
which is licensed under the Python Software Foundation License (PSF).
License information is provided within the embedded distribution.

---

This repository includes DejaVu Sans Condensed font files (TTF),
which are distributed under their own license.
Please refer to the font files or accompanying license information for details.

---

### Academic use

If you use the FcsIT software or any part of it in your academic work, 
citation of the relevant publications listed below is appreciated.    
1. Kalwarczyk, T. (2026). FcsIT: An Open-Source, Cross-Platform Tool for Correlation and Analysis of Fluorescence Correlation Spectroscopy Data. https://doi.org/10.48550/arXiv.2603.29684
2. Kalwarczyk, T. (2026). FcsIT - A simple and easy-to-use tool for correlating and fitting the fluorescence correlation spectroscopy (FCS) data. https://doi.org/10.5281/zenodo.19351493
